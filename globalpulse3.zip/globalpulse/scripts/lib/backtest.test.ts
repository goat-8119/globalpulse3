import { describe, it, expect } from "vitest";
import { runBacktest, PricePoint } from "./backtest";

function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;
  };
}

function buildRandomWalk(n: number, seed: number): PricePoint[] {
  const rand = seededRandom(seed);
  const points: PricePoint[] = [];
  let price = 100;
  for (let i = 0; i < n; i++) {
    const pctChange = (rand() - 0.5) * 4; // +/-2% daily noise, no drift, no signal
    if (i > 0) price = price * (1 + pctChange / 100);
    points.push({ t: i, close: price, pctChange1d: i > 0 ? pctChange : null });
  }
  return points;
}

function buildTrendingSeries(n: number, driftPct: number): PricePoint[] {
  const points: PricePoint[] = [];
  let price = 100;
  for (let i = 0; i < n; i++) {
    if (i > 0) price = price * (1 + driftPct / 100);
    points.push({ t: i, close: price, pctChange1d: i > 0 ? driftPct : null });
  }
  return points;
}

describe("runBacktest", () => {
  it("produces a hit rate close to 50% on pure random-walk noise (no real signal to find)", () => {
    // This is the single most important test in this file: if a backtest
    // shows a real edge on data that is BY CONSTRUCTION unpredictable
    // (each day's move is independent random noise with zero drift), that
    // proves a lookahead bug or other cheat, not a good signal.
    const series = buildRandomWalk(500, 42);
    const result = runBacktest(series, 5, 30);
    expect(result.totalSignals).toBeGreaterThan(50);
    // Allow a wide band — even a correct, unbiased backtest will drift from
    // exactly 50% on any finite sample. The point is it should NOT be near
    // 70-80%, which would indicate the test is cheating.
    expect(result.hitRate).toBeGreaterThan(0.35);
    expect(result.hitRate).toBeLessThan(0.65);
  });

  it("correctly identifies a strongly trending series as mostly bullish signals", () => {
    const series = buildTrendingSeries(200, 0.5); // steady +0.5%/day uptrend
    const result = runBacktest(series, 5, 30);
    const bullishCount = result.trades.filter((t) => t.signalDirection === "bullish").length;
    const bearishCount = result.trades.filter((t) => t.signalDirection === "bearish").length;
    expect(bullishCount).toBeGreaterThan(bearishCount);
  });

  it("never uses data from after the signal date (no lookahead)", () => {
    // Construct a series that is flat, then has one giant one-day spike far
    // in the future. A signal computed BEFORE that spike must not "see" it.
    const series = buildRandomWalk(100, 7);
    series[90] = { t: 90, close: series[89]!.close * 3, pctChange1d: 200 }; // huge future spike
    const result = runBacktest(series, 5, 30);
    // Every signal computed at index < 90 should be unaffected by the spike
    // at 90 — check that early signal scores aren't anomalously extreme.
    const earlySignals = result.trades.filter((t) => t.signalDate < 85);
    for (const s of earlySignals) {
      expect(s.signalScore).toBeGreaterThan(0);
      expect(s.signalScore).toBeLessThan(100);
    }
  });

  it("returns zero signals when there is not enough trailing history", () => {
    const series = buildRandomWalk(10, 1);
    const result = runBacktest(series, 5, 30);
    expect(result.totalSignals).toBe(0);
    expect(result.hitRate).toBe(0);
  });

  it("computes mean forward return separately for bullish vs bearish calls", () => {
    const series = buildTrendingSeries(200, 0.3);
    const result = runBacktest(series, 5, 30);
    if (result.meanForwardReturnWhenBullish !== null) {
      expect(result.meanForwardReturnWhenBullish).toBeGreaterThan(0); // trending up, bullish calls should on average be followed by more upside
    }
  });
});
