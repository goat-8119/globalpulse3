"use client";

import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

type HistoryPoint = { value: number; capturedAt: string; pctChange1d: number | null };

const TIMEFRAMES = [
  { label: "1W", limit: 7 },
  { label: "1M", limit: 30 },
  { label: "3M", limit: 90 },
  { label: "1Y", limit: 365 },
  { label: "5Y", limit: 1825 },
  { label: "MAX", limit: 20000 },
];

export function IndicatorChart({ iso3, canonicalKey, unit }: { iso3: string; canonicalKey: string; unit: string | null }) {
  const [timeframe, setTimeframe] = useState(TIMEFRAMES[2]!); // default 3M
  const [data, setData] = useState<HistoryPoint[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/countries/${iso3}/history/${canonicalKey}?limit=${timeframe.limit}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(r)))
      .then((d) => {
        if (!cancelled) setData(d.history ?? []);
      })
      .catch(() => {
        if (!cancelled) setData([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [iso3, canonicalKey, timeframe]);

  const chartData = (data ?? []).map((p) => ({
    date: new Date(p.capturedAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: timeframe.limit > 400 ? "numeric" : undefined }),
    value: p.value,
  }));

  const trendUp = chartData.length > 1 && chartData[chartData.length - 1]!.value >= chartData[0]!.value;

  return (
    <div style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 8, padding: "16px 16px 8px", marginTop: 8, marginBottom: 8 }}>
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        {TIMEFRAMES.map((tf) => (
          <button
            key={tf.label}
            onClick={() => setTimeframe(tf)}
            className="mono"
            style={{
              fontSize: 11,
              padding: "4px 10px",
              borderRadius: 999,
              border: "1px solid var(--rule)",
              background: tf.label === timeframe.label ? "var(--paper)" : "transparent",
              color: tf.label === timeframe.label ? "var(--accent-gold)" : "var(--ink-muted)",
              cursor: "pointer",
            }}
          >
            {tf.label}
          </button>
        ))}
      </div>

      {loading && <div className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", padding: "40px 0", textAlign: "center" }}>loading…</div>}

      {!loading && chartData.length < 2 && (
        <div className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", padding: "40px 0", textAlign: "center" }}>
          Not enough history for this timeframe yet.
        </div>
      )}

      {!loading && chartData.length >= 2 && (
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--rule)" />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: "var(--ink-muted)" }} minTickGap={40} axisLine={{ stroke: "var(--rule)" }} tickLine={false} />
            <YAxis
              domain={["auto", "auto"]}
              tick={{ fontSize: 10, fill: "var(--ink-muted)" }}
              width={56}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v: number) => v.toLocaleString(undefined, { maximumFractionDigits: 1 })}
            />
            <Tooltip
              contentStyle={{ background: "var(--paper)", border: "1px solid var(--rule)", borderRadius: 6, fontSize: 12 }}
              labelStyle={{ color: "var(--ink-muted)" }}
              formatter={(v: number) => [`${v.toLocaleString(undefined, { maximumFractionDigits: 2 })}${unit && unit !== "%" ? ` ${unit}` : ""}`, "Value"]}
            />
            <Line type="monotone" dataKey="value" stroke={trendUp ? "var(--signal-up)" : "var(--signal-down)"} strokeWidth={1.75} dot={false} isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
