import "dotenv/config";
import { getSql } from "../lib/db";
import { runBacktest, PricePoint } from "./lib/backtest";
import { startJobRun, finishJobRun } from "./lib/upsert";

// Section 6/10 pattern: this is a compute job, not an ingest job — it reads
// what's already in observations (no external calls) and writes a summary
// to backtest_results. Safe to re-run any time new history accumulates.
const JOB_NAME = "run-backtests";
const HORIZON_DAYS = 5;

async function main() {
  const sql = getSql();
  const { startedAt } = await startJobRun(JOB_NAME);

  const indicators = await sql`
    SELECT id, country_id, display_name FROM indicators
    WHERE canonical_key IN ('stock_index_headline', 'stock_index_sp500')
  `;

  let written = 0;
  for (const ind of indicators) {
    const rows = await sql`
      SELECT value, pct_change_1d, captured_at FROM observations
      WHERE indicator_id = ${ind.id}
      ORDER BY captured_at ASC
    `;
    if (rows.length < 60) {
      console.log(`  SKIP ${ind.display_name} — only ${rows.length} days of history, need 60+`);
      continue;
    }

    const series: PricePoint[] = rows.map((r, i) => ({
      t: i,
      close: Number(r.value),
      pctChange1d: r.pct_change_1d === null ? null : Number(r.pct_change_1d),
    }));

    const result = runBacktest(series, HORIZON_DAYS, 30);
    if (result.totalSignals === 0) {
      console.log(`  SKIP ${ind.display_name} — no directional signals produced`);
      continue;
    }

    await sql`
      INSERT INTO backtest_results (
        indicator_id, horizon_days, total_signals, neutral_signals, hit_rate,
        mean_forward_return_bullish, mean_forward_return_bearish, computed_at
      )
      VALUES (
        ${ind.id}, ${HORIZON_DAYS}, ${result.totalSignals}, ${result.neutralSignals}, ${result.hitRate},
        ${result.meanForwardReturnWhenBullish}, ${result.meanForwardReturnWhenBearish}, ${new Date().toISOString()}
      )
    `;
    written++;
    console.log(`  OK  ${ind.display_name} — ${result.totalSignals} signals, hit rate ${(result.hitRate * 100).toFixed(1)}%`);
  }

  await finishJobRun(JOB_NAME, startedAt, "success", written);
  console.log(`\nDone. ${written} backtest results written.`);
}

main().catch((err) => {
  console.error("Backtest run failed:", err);
  process.exit(1);
});
