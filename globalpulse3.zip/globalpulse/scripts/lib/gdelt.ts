import { z } from "zod";
import { fetchWithRetry } from "./retry";

// GDELT 2.0 DOC API — free, no key, explicitly designed for this exact use
// case (confirmed via their own blog: CORS wildcard header, JSON output
// mode, built for "web-first workflows"). This is a genuine exception to
// this app's usual ingest-vs-serve rule (Section 2): every other data
// source is fetched by a cron job and stored, then served from Postgres.
// News doesn't fit that shape — it's "what's happening right now," not a
// time series to accumulate — so this is called live from the API route,
// not backfilled. See app/api/news/route.ts for the caching that keeps
// this a good citizen of GDELT's free service despite calling it live.
const GDELT_ENDPOINT = "https://api.gdeltproject.org/api/v2/doc/doc";

// Field names confirmed against the actively-maintained gdelt-doc-api
// Python client's documented output columns, not guessed from prose docs alone.
const GdeltArticleSchema = z.object({
  url: z.string(),
  title: z.string(),
  seendate: z.string().optional(),
  domain: z.string().optional(),
  language: z.string().optional(),
  sourcecountry: z.string().optional(),
});

const GdeltResponseSchema = z.object({
  articles: z.array(GdeltArticleSchema).optional(),
});

export type NewsHeadline = {
  title: string;
  url: string;
  domain: string | null;
  seenDate: string | null;
  sourceCountry: string | null;
};

/**
 * GDELT's sourcecountry filter technically wants a FIPS 2-letter code, which
 * has real gotchas (FIPS Austria='AU' collides with ISO Australia='AU') —
 * rather than hand-maintain a 197-entry FIPS table from memory and risk a
 * silent transcription error, this uses the simpler form GDELT's own blog
 * confirms also works: the country's lowercase English name with spaces
 * stripped (e.g. "france", "unitedarabemirates"). This will miss a handful
 * of countries where GDELT's internal label doesn't match that naive
 * transform — disclosed, not silently swallowed.
 */
export function toGdeltCountryToken(countryName: string): string {
  return countryName.toLowerCase().replace(/[^a-z]/g, "");
}

export async function fetchFinanceHeadlines(opts: { countryName?: string; maxRecords?: number; timespan?: string } = {}): Promise<NewsHeadline[]> {
  const { countryName, maxRecords = 20, timespan = "2d" } = opts;

  const topicFilter = "(business OR finance OR economy OR markets OR economic)";
  const countryFilter = countryName ? ` sourcecountry:${toGdeltCountryToken(countryName)}` : "";
  const query = topicFilter + countryFilter;

  const params = new URLSearchParams({
    query,
    mode: "artlist",
    format: "json",
    maxrecords: String(Math.min(maxRecords, 250)),
    timespan,
    sort: "datedesc",
  });

  const raw = await fetchWithRetry(`${GDELT_ENDPOINT}?${params.toString()}`, { retries: 2, baseDelayMs: 800 });
  const parsed = GdeltResponseSchema.safeParse(raw);

  if (!parsed.success) {
    throw new Error(`Unexpected GDELT response shape: ${parsed.error.message}`);
  }

  return (parsed.data.articles ?? []).map((a) => ({
    title: a.title,
    url: a.url,
    domain: a.domain ?? null,
    seenDate: a.seendate ?? null,
    sourceCountry: a.sourcecountry ?? null,
  }));
}
