import { NextResponse } from "next/server";
import { getSql } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const sql = getSql();
  const rows = await sql`
    SELECT DISTINCT ON (br.indicator_id)
      c.iso3, c.name AS country_name, c.flag_emoji, i.display_name,
      br.horizon_days, br.total_signals, br.neutral_signals, br.hit_rate,
      br.mean_forward_return_bullish, br.mean_forward_return_bearish, br.computed_at
    FROM backtest_results br
    JOIN indicators i ON i.id = br.indicator_id
    JOIN countries c ON c.id = i.country_id
    ORDER BY br.indicator_id, br.computed_at DESC
  `;

  return NextResponse.json({
    results: rows.map((r) => ({
      iso3: r.iso3,
      countryName: r.country_name,
      flagEmoji: r.flag_emoji,
      indicatorName: r.display_name,
      horizonDays: r.horizon_days,
      totalSignals: r.total_signals,
      neutralSignals: r.neutral_signals,
      hitRate: Number(r.hit_rate),
      meanForwardReturnBullish: r.mean_forward_return_bullish === null ? null : Number(r.mean_forward_return_bullish),
      meanForwardReturnBearish: r.mean_forward_return_bearish === null ? null : Number(r.mean_forward_return_bearish),
      computedAt: r.computed_at,
    })),
  });
}
