import Link from "next/link";
import { notFound } from "next/navigation";
import { getSql } from "@/lib/db";
import { getCountryDashboard, getJobFreshness } from "@/lib/queries";
import { BriefingPanel } from "./briefing-panel";
import { NewsPanel } from "./news-panel";
import { IndicatorTable } from "./indicator-table";
import { ShareButton } from "./share-button";

export const dynamic = "force-dynamic";

const INDEX_LABELS: Record<string, string> = {
  market_momentum: "Market Momentum",
  macro_health: "Macro Health",
  trend_projection: "Trend Projection",
  composite_signal: "Composite Signal Score",
};

export default async function CountryPage({ params }: { params: Promise<{ iso3: string }> }) {
  const { iso3 } = await params;
  const sql = getSql();
  const dashboard = await getCountryDashboard(sql, iso3);
  if (!dashboard) notFound();
  const freshness = await getJobFreshness(sql, "ingest-market");

  const { country, indicators, growthIndexes } = dashboard;
  const grouped = indicators.reduce<Record<string, typeof indicators>>((acc, ind) => {
    (acc[ind.category] ??= []).push(ind);
    return acc;
  }, {});

  return (
    <main style={{ maxWidth: 1000, margin: "0 auto", padding: "40px 24px 96px" }}>
      <Link href="/" className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", textDecoration: "none" }}>
        ← ALL COUNTRIES
      </Link>

      <header style={{ display: "flex", alignItems: "center", gap: 12, margin: "16px 0 32px", flexWrap: "wrap" }}>
        <span style={{ fontSize: 36 }}>{country.flagEmoji}</span>
        <div style={{ flex: 1 }}>
          <h1 style={{ fontSize: 26 }}>{country.name}</h1>
          <span className="mono" style={{ fontSize: 12, color: "var(--ink-muted)" }}>
            {country.iso3} {country.region ? `· ${country.region}` : ""}
          </span>
        </div>
        {freshness && (
          <span className="mono" style={{ fontSize: 11, color: "var(--ink-muted)", display: "flex", alignItems: "center", gap: 6 }}>
            <span
              style={{
                display: "inline-block", width: 6, height: 6, borderRadius: "50%",
                background: freshness.minutesSince <= 45 ? "var(--signal-up)" : freshness.minutesSince <= 24 * 60 ? "var(--signal-flag)" : "var(--signal-down)",
              }}
            />
            data refreshed {freshness.minutesSince < 60 ? `${freshness.minutesSince}m` : `${Math.round(freshness.minutesSince / 60)}h`} ago
          </span>
        )}
        <a href={`/api/countries/${country.iso3}/export`} className="mono" style={{ fontSize: 11, color: "var(--accent-gold)", textDecoration: "none" }}>
          ↓ CSV
        </a>
        <ShareButton iso3={country.iso3} />
      </header>

      {Object.keys(growthIndexes).length > 0 && (
        <section style={{ marginBottom: 40 }}>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {Object.entries(growthIndexes).map(([type, idx]) => (
              <div key={type} style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 8, padding: "16px 20px", minWidth: 160 }}>
                <div style={{ fontSize: 10, color: "var(--ink-muted)", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.04em" }}>
                  {INDEX_LABELS[type] ?? type}
                </div>
                <div className="mono" style={{ fontSize: 24, fontWeight: 600 }}>
                  {idx.score.toFixed(1)}
                </div>
                {idx.confidence !== null && (
                  <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 4 }}>
                    {type === "composite_signal" ? "signal agreement" : "confidence"} {(idx.confidence * 100).toFixed(0)}%
                  </div>
                )}
              </div>
            ))}
          </div>
          {growthIndexes.composite_signal && (
            <p className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", marginTop: 8, maxWidth: 500, lineHeight: 1.5 }}>
              Composite Signal Score averages three standard quant signals (momentum, mean-reversion,
              volatility-adjusted momentum). It is not a prediction — low signal agreement means the underlying
              signals actually disagree with each other, not just that the average looks uncertain.
            </p>
          )}
        </section>
      )}

      <BriefingPanel iso3={country.iso3} />
      <NewsPanel iso3={country.iso3} />

      {indicators.length === 0 ? (
        <p style={{ color: "var(--ink-muted)" }}>No indicators seeded for this country yet.</p>
      ) : (
        <IndicatorTable iso3={country.iso3} grouped={grouped} />
      )}
    </main>
  );
}
