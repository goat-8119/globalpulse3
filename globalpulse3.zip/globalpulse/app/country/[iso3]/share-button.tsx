"use client";

import { useState } from "react";

export function ShareButton({ iso3 }: { iso3: string }) {
  const [status, setStatus] = useState<"idle" | "loading" | "copied">("idle");

  async function share() {
    setStatus("loading");
    try {
      const res = await fetch("/api/share", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dashboardType: "country", iso3 }),
      });
      const data = await res.json();
      const fullUrl = `${window.location.origin}${data.url}`;
      await navigator.clipboard.writeText(fullUrl);
      setStatus("copied");
      setTimeout(() => setStatus("idle"), 2000);
    } catch {
      setStatus("idle");
    }
  }

  return (
    <button onClick={share} className="mono" style={{ fontSize: 11, color: "var(--accent-gold)", background: "none", border: "none", cursor: "pointer" }}>
      {status === "loading" ? "…" : status === "copied" ? "✓ link copied" : "↗ share"}
    </button>
  );
}
