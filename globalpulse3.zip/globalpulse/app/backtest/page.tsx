"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type BacktestResult = {
  iso3: string;
  countryName: string;
  flagEmoji: string | null;
  indicatorName: string;
  horizonDays: number;
  totalSignals: number;
  neutralSignals: number;
  hitRate: number;
  meanForwardReturnBullish: number | null;
  meanForwardReturnBearish: number | null;
  computedAt: string;
};

function hitRateColor(rate: number): string {
  // Deliberately NOT green-at-high/red-at-low the way other pages are — a
  // hit rate near 50% is the EXPECTED, honest outcome for a real signal,
  // not a bad result. Only flag as notable if it's unusually far from 50%
  // in either direction (which is itself worth a second look, not celebration).
  if (rate > 0.65 || rate < 0.35) return "var(--signal-flag)";
  return "var(--ink)";
}

export default function BacktestPage() {
  const [results, setResults] = useState<BacktestResult[] | null>(null);

  useEffect(() => {
    fetch("/api/backtest")
      .then((r) => r.json())
      .then((d) => setResults(d.results ?? []));
  }, []);

  const avgHitRate = results && results.length > 0 ? results.reduce((sum, r) => sum + r.hitRate, 0) / results.length : null;

  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: "40px 24px 96px" }}>
      <Link href="/" className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", textDecoration: "none" }}>
        ← ALL COUNTRIES
      </Link>
      <h1 style={{ fontSize: 26, margin: "16px 0 8px" }}>Track Record</h1>

      <div style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 8, padding: 16, marginBottom: 28, maxWidth: 640 }}>
        <p style={{ margin: 0, fontSize: 13, lineHeight: 1.6, color: "var(--ink-muted)" }}>
          This page shows how the Composite Signal Score has actually performed historically — not a claim, a
          measurement. At each point in a country&apos;s price history, the signal is computed using only data
          available up to that point (no lookahead), then checked against what actually happened over the following
          5 trading days. <strong style={{ color: "var(--ink)" }}>A hit rate near 50% is the expected, correct
          result for a real signal</strong> — that&apos;s what &quot;no legitimate technique reliably predicts
          markets&quot; looks like when you actually measure it. Professional quant funds report 52–55% as
          excellent. A rate far above that on this page would be more likely to indicate a flawed test than a
          genuinely powerful signal.
        </p>
      </div>

      {avgHitRate !== null && (
        <div style={{ marginBottom: 28 }}>
          <div className="label" style={{ fontSize: 10, color: "var(--ink-muted)", textTransform: "uppercase" }}>
            Average hit rate across all tested countries
          </div>
          <div className="mono" style={{ fontSize: 32, fontWeight: 600, color: hitRateColor(avgHitRate) }}>
            {(avgHitRate * 100).toFixed(1)}%
          </div>
        </div>
      )}

      {results === null && <p className="mono" style={{ color: "var(--ink-muted)", fontSize: 13 }}>loading…</p>}

      {results !== null && results.length === 0 && (
        <p style={{ color: "var(--ink-muted)" }}>
          No backtest results yet. Run <code className="mono">npx tsx scripts/run-backtests.ts</code> once there&apos;s
          at least ~60 days of price history for a country&apos;s headline index.
        </p>
      )}

      {results !== null && results.length > 0 && (
        <div style={{ overflowX: "auto" }}>
          <table style={{ borderCollapse: "collapse", width: "100%" }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: "8px 12px 8px 0", borderBottom: "1px solid var(--rule)", fontSize: 11, color: "var(--ink-muted)", textTransform: "uppercase" }}>Country</th>
                <th style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)", fontSize: 11, color: "var(--ink-muted)", textTransform: "uppercase" }}>Hit Rate</th>
                <th style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)", fontSize: 11, color: "var(--ink-muted)", textTransform: "uppercase" }}>Signals Tested</th>
                <th style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)", fontSize: 11, color: "var(--ink-muted)", textTransform: "uppercase" }}>Avg Fwd Return (Bullish)</th>
                <th style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)", fontSize: 11, color: "var(--ink-muted)", textTransform: "uppercase" }}>Avg Fwd Return (Bearish)</th>
              </tr>
            </thead>
            <tbody>
              {results.map((r) => (
                <tr key={r.iso3}>
                  <td style={{ padding: "8px 12px 8px 0", borderBottom: "1px solid var(--rule)", fontSize: 13 }}>
                    {r.flagEmoji} {r.countryName}
                  </td>
                  <td className="mono" style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)", color: hitRateColor(r.hitRate) }}>
                    {(r.hitRate * 100).toFixed(1)}%
                  </td>
                  <td className="mono" style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)", color: "var(--ink-muted)" }}>
                    {r.totalSignals}
                  </td>
                  <td className="mono up" style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)" }}>
                    {r.meanForwardReturnBullish === null ? "—" : `${r.meanForwardReturnBullish > 0 ? "+" : ""}${r.meanForwardReturnBullish.toFixed(2)}%`}
                  </td>
                  <td className="mono down" style={{ textAlign: "right", padding: "8px 12px", borderBottom: "1px solid var(--rule)" }}>
                    {r.meanForwardReturnBearish === null ? "—" : `${r.meanForwardReturnBearish.toFixed(2)}%`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
