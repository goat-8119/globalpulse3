"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type Headline = { title: string; url: string; domain: string | null; seenDate: string | null; sourceCountry: string | null };

function fmtDate(seenDate: string | null): string {
  if (!seenDate) return "";
  // GDELT format: YYYYMMDDTHHMMSSZ
  const match = seenDate.match(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})/);
  if (!match) return "";
  const [, y, mo, d, h, mi] = match;
  return new Date(Date.UTC(Number(y), Number(mo) - 1, Number(d), Number(h), Number(mi))).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export default function NewsPage() {
  const [headlines, setHeadlines] = useState<Headline[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/news")
      .then((r) => r.json())
      .then((d) => {
        setHeadlines(d.headlines ?? []);
        if (d.error) setError(d.error);
      });
  }, []);

  return (
    <main style={{ maxWidth: 800, margin: "0 auto", padding: "40px 24px 96px" }}>
      <Link href="/" className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", textDecoration: "none" }}>
        ← ALL COUNTRIES
      </Link>
      <h1 style={{ fontSize: 26, margin: "16px 0 8px" }}>Headlines</h1>
      <p style={{ color: "var(--ink-muted)", marginTop: 0, marginBottom: 28, maxWidth: 560 }}>
        Recent business and finance coverage from global news outlets, via the GDELT Project — live, not stored, so
        this always reflects the last couple of days rather than a searchable history.
      </p>

      {headlines === null && <p className="mono" style={{ color: "var(--ink-muted)", fontSize: 13 }}>loading…</p>}
      {error && headlines !== null && headlines.length === 0 && (
        <p style={{ color: "var(--ink-muted)" }}>Headlines are temporarily unavailable ({error}). Try again shortly.</p>
      )}
      {headlines !== null && headlines.length === 0 && !error && <p style={{ color: "var(--ink-muted)" }}>No recent headlines found.</p>}

      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {(headlines ?? []).map((h, i) => (
          <a
            key={i}
            href={h.url}
            target="_blank"
            rel="noopener noreferrer"
            style={{ display: "block", padding: "12px 0", borderBottom: "1px solid var(--rule)", textDecoration: "none", color: "inherit" }}
          >
            <div style={{ fontSize: 14, lineHeight: 1.4, marginBottom: 4 }}>{h.title}</div>
            <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>
              {h.domain} {h.seenDate ? `· ${fmtDate(h.seenDate)}` : ""}
            </div>
          </a>
        ))}
      </div>
    </main>
  );
}
