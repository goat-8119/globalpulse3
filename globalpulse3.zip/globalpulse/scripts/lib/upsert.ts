import { getSql } from "../../lib/db";
import { ComputedChanges } from "./changes";

/**
 * Idempotent write (Section 7): ON CONFLICT DO NOTHING on (indicator_id, captured_at)
 * means re-running a backfill or a cron tick twice never creates duplicate rows.
 */
export async function upsertObservation(
  indicatorId: number,
  value: number,
  changes: ComputedChanges,
  capturedAt: Date,
  periodLabel: string | null = null
): Promise<void> {
  const sql = getSql();
  await sql`
    INSERT INTO observations (
      indicator_id, value, change, pct_change_1d, pct_change_1w, pct_change_1m,
      pct_change_ytd, pct_change_1y, period_label, captured_at
    )
    VALUES (
      ${indicatorId}, ${value}, ${changes.change}, ${changes.pctChange1d}, ${changes.pctChange1w},
      ${changes.pctChange1m}, ${changes.pctChangeYtd}, ${changes.pctChange1y}, ${periodLabel}, ${capturedAt.toISOString()}
    )
    ON CONFLICT (indicator_id, captured_at) DO NOTHING
  `;
}

export type BulkObservationRow = {
  value: number;
  changes: ComputedChanges;
  capturedAt: Date;
};

/**
 * Bulk variant using unnest() to insert many rows in ONE round-trip instead
 * of one round-trip per row. This matters at "max history" scale — a single
 * long-lived index can have 10,000+ daily closes, and one HTTP call per row
 * would make a full backfill take hours instead of seconds. Postgres's
 * unnest() takes parallel arrays and expands them into rows server-side.
 */
export async function upsertObservationsBulk(indicatorId: number, rows: BulkObservationRow[]): Promise<number> {
  if (rows.length === 0) return 0;
  const sql = getSql();

  // Neon's practical limit per query is generous, but chunking keeps each
  // request well within safe payload/time bounds even for the longest series.
  const CHUNK_SIZE = 2000;
  let written = 0;

  for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
    const chunk = rows.slice(i, i + CHUNK_SIZE);
    const values = chunk.map((r) => r.value);
    const changeArr = chunk.map((r) => r.changes.change);
    const pct1d = chunk.map((r) => r.changes.pctChange1d);
    const pct1w = chunk.map((r) => r.changes.pctChange1w);
    const pct1m = chunk.map((r) => r.changes.pctChange1m);
    const pctYtd = chunk.map((r) => r.changes.pctChangeYtd);
    const pct1y = chunk.map((r) => r.changes.pctChange1y);
    const capturedAts = chunk.map((r) => r.capturedAt.toISOString());
    const indicatorIds = chunk.map(() => indicatorId);

    const result = await sql`
      INSERT INTO observations (indicator_id, value, change, pct_change_1d, pct_change_1w, pct_change_1m, pct_change_ytd, pct_change_1y, captured_at)
      SELECT * FROM unnest(
        ${indicatorIds}::int[], ${values}::numeric[], ${changeArr}::numeric[],
        ${pct1d}::numeric[], ${pct1w}::numeric[], ${pct1m}::numeric[],
        ${pctYtd}::numeric[], ${pct1y}::numeric[], ${capturedAts}::timestamptz[]
      )
      ON CONFLICT (indicator_id, captured_at) DO NOTHING
      RETURNING id
    `;
    written += result.length;
  }

  return written;
}

export async function startJobRun(jobName: string): Promise<{ startedAt: Date }> {
  return { startedAt: new Date() };
}

export async function finishJobRun(
  jobName: string,
  startedAt: Date,
  status: "success" | "partial" | "failed",
  recordsWritten: number,
  errorMessage: string | null = null
): Promise<void> {
  const sql = getSql();
  await sql`
    INSERT INTO job_runs (job_name, status, records_written, error_message, started_at, finished_at)
    VALUES (${jobName}, ${status}, ${recordsWritten}, ${errorMessage}, ${startedAt.toISOString()}, ${new Date().toISOString()})
  `;
}
