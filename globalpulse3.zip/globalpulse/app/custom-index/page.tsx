"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type CountryOption = { iso3: string; name: string; flagEmoji: string | null };
type IndicatorOption = { id: number; displayName: string };
type SavedIndex = {
  id: number;
  name: string;
  score: number | null;
  components: { indicatorId: number; displayName: string; weight: number; pctChange1d: number | null }[];
};

export default function CustomIndexPage() {
  const [countries, setCountries] = useState<CountryOption[]>([]);
  const [activeIso3, setActiveIso3] = useState("USA");
  const [indicators, setIndicators] = useState<IndicatorOption[]>([]);
  const [weights, setWeights] = useState<Record<number, number>>({});
  const [name, setName] = useState("");
  const [saved, setSaved] = useState<SavedIndex[] | null>(null);
  const [saving, setSaving] = useState(false);

  function refresh() {
    fetch("/api/custom-index").then((r) => r.json()).then((d) => setSaved(d.indexes ?? []));
  }

  useEffect(() => {
    refresh();
    fetch("/api/countries").then((r) => r.json()).then((d) => setCountries(d.countries ?? []));
  }, []);

  useEffect(() => {
    fetch(`/api/countries/${activeIso3}`)
      .then((r) => r.json())
      .then((d) => setIndicators((d.indicators ?? []).map((i: { id: number; displayName: string }) => ({ id: i.id, displayName: i.displayName }))));
  }, [activeIso3]);

  function setWeight(id: number, w: string) {
    const num = Number(w);
    setWeights((prev) => {
      const next = { ...prev };
      if (w === "" || num === 0) delete next[id];
      else next[id] = num;
      return next;
    });
  }

  async function save() {
    if (!name.trim() || Object.keys(weights).length === 0) return;
    setSaving(true);
    try {
      await fetch("/api/custom-index", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), weights }),
      });
      setName("");
      setWeights({});
      refresh();
    } finally {
      setSaving(false);
    }
  }

  const componentCount = Object.keys(weights).length;

  return (
    <main style={{ maxWidth: 800, margin: "0 auto", padding: "40px 24px 96px" }}>
      <Link href="/" className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", textDecoration: "none" }}>
        ← ALL COUNTRIES
      </Link>
      <h1 style={{ fontSize: 26, margin: "16px 0 8px" }}>Custom Index Builder</h1>
      <p style={{ color: "var(--ink-muted)", marginTop: 0, marginBottom: 28, maxWidth: 560 }}>
        Combine any indicators from any countries into your own weighted composite. Positive weight moves the score
        up when the indicator rises; negative weight inverts it (useful for hedges — e.g. weight a currency
        negatively if you want the index to rise when that currency falls).
      </p>

      {saved !== null && saved.length > 0 && (
        <section style={{ marginBottom: 32 }}>
          <div className="label" style={{ fontSize: 10, color: "var(--ink-muted)", textTransform: "uppercase", marginBottom: 12 }}>Your Indexes</div>
          {saved.map((idx) => (
            <div key={idx.id} style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 8, padding: 16, marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
                <span style={{ fontWeight: 500 }}>{idx.name}</span>
                <span className="mono" style={{ fontSize: 20, fontWeight: 600 }}>{idx.score === null ? "—" : idx.score.toFixed(1)}</span>
              </div>
              <div className="mono" style={{ fontSize: 11, color: "var(--ink-muted)" }}>
                {idx.components.map((c) => `${c.displayName} (${c.weight > 0 ? "+" : ""}${c.weight})`).join(" · ")}
              </div>
            </div>
          ))}
        </section>
      )}

      <section>
        <div className="label" style={{ fontSize: 10, color: "var(--ink-muted)", textTransform: "uppercase", marginBottom: 12 }}>Build a new index</div>

        <select value={activeIso3} onChange={(e) => setActiveIso3(e.target.value)} style={{ marginBottom: 16 }}>
          {countries.map((c) => (
            <option key={c.iso3} value={c.iso3}>
              {c.flagEmoji} {c.name}
            </option>
          ))}
        </select>

        <div style={{ display: "flex", flexDirection: "column", gap: 4, marginBottom: 20 }}>
          {indicators.map((ind) => (
            <div key={ind.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0", borderBottom: "1px solid var(--rule)" }}>
              <span style={{ flex: 1, fontSize: 13 }}>{ind.displayName}</span>
              <input
                type="number"
                placeholder="weight"
                value={weights[ind.id] ?? ""}
                onChange={(e) => setWeight(ind.id, e.target.value)}
                style={{ width: 90, fontSize: 12 }}
              />
            </div>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Index name" style={{ flex: 1 }} />
          <button
            onClick={save}
            disabled={saving || !name.trim() || componentCount === 0}
            style={{
              background: "var(--accent-gold)", color: "var(--paper)", border: "none", borderRadius: 6,
              padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer", opacity: saving ? 0.6 : 1,
            }}
          >
            {saving ? "Saving…" : `Save (${componentCount})`}
          </button>
        </div>
      </section>
    </main>
  );
}
