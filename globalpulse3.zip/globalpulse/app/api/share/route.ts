import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { getCountryDashboard } from "@/lib/queries";

export const dynamic = "force-dynamic";

const CreateShareSchema = z.object({
  dashboardType: z.enum(["country", "compare", "correlation"]),
  iso3: z.string().optional(), // required for 'country'
  payload: z.unknown().optional(), // for 'compare'/'correlation', caller already has the data client-side
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = CreateShareSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid body", issues: parsed.error.issues }, { status: 400 });

  const sql = getSql();
  let snapshot: unknown;

  if (parsed.data.dashboardType === "country") {
    if (!parsed.data.iso3) return NextResponse.json({ error: "iso3 required for country dashboards" }, { status: 400 });
    snapshot = await getCountryDashboard(sql, parsed.data.iso3);
    if (!snapshot) return NextResponse.json({ error: `Country '${parsed.data.iso3}' not found` }, { status: 404 });
  } else {
    // compare/correlation snapshots are computed client-side already (the
    // page has the data in state) — the client just asks us to freeze
    // exactly what it's showing right now.
    if (!parsed.data.payload) return NextResponse.json({ error: "payload required for compare/correlation" }, { status: 400 });
    snapshot = parsed.data.payload;
  }

  const token = randomBytes(12).toString("base64url"); // opaque, unguessable
  await sql`
    INSERT INTO shared_dashboards (share_token, dashboard_type, snapshot_data, expires_at)
    VALUES (${token}, ${parsed.data.dashboardType}, ${JSON.stringify(snapshot)}, ${new Date(Date.now() + 90 * 86400 * 1000).toISOString()})
  `;

  return NextResponse.json({ token, url: `/share/${token}` }, { status: 201 });
}
