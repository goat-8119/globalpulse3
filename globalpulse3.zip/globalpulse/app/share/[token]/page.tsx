import Link from "next/link";
import { notFound } from "next/navigation";
import { getSql } from "@/lib/db";

export const dynamic = "force-dynamic";

type CountrySnapshot = {
  country: { iso3: string; name: string; flagEmoji: string | null };
  indicators: { displayName: string; category: string; value: number | null; unit: string | null; pctChange1d: number | null }[];
  growthIndexes: Record<string, { score: number }>;
};

export default async function SharedDashboardPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const sql = getSql();

  const rows = await sql`
    SELECT dashboard_type, snapshot_data, created_at, expires_at FROM shared_dashboards
    WHERE share_token = ${token}
  `;
  const row = rows[0];
  if (!row) notFound();
  if (row.expires_at && new Date(row.expires_at) < new Date()) {
    return (
      <main style={{ maxWidth: 700, margin: "0 auto", padding: "60px 24px" }}>
        <p style={{ color: "var(--ink-muted)" }}>This shared link has expired.</p>
        <Link href="/" className="mono" style={{ color: "var(--accent-gold)" }}>← Back to GlobalPulse</Link>
      </main>
    );
  }

  const createdAt = new Date(row.created_at as string).toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" });

  if (row.dashboard_type === "country") {
    const snap = row.snapshot_data as CountrySnapshot;
    return (
      <main style={{ maxWidth: 900, margin: "0 auto", padding: "40px 24px 96px" }}>
        <div style={{ background: "var(--paper-raised)", border: "1px solid var(--signal-flag)", borderRadius: 8, padding: 12, marginBottom: 24, fontSize: 13 }}>
          📸 Snapshot from <strong>{createdAt}</strong> — this is frozen, not live. <Link href={`/country/${snap.country.iso3}`} style={{ color: "var(--accent-gold)" }}>View live data →</Link>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 28 }}>
          <span style={{ fontSize: 34 }}>{snap.country.flagEmoji}</span>
          <h1 style={{ fontSize: 26 }}>{snap.country.name}</h1>
        </div>
        {Object.entries(snap.growthIndexes).length > 0 && (
          <div style={{ display: "flex", gap: 12, marginBottom: 28, flexWrap: "wrap" }}>
            {Object.entries(snap.growthIndexes).map(([type, idx]) => (
              <div key={type} style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 8, padding: "12px 16px" }}>
                <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", textTransform: "uppercase" }}>{type.replace("_", " ")}</div>
                <div className="mono" style={{ fontSize: 20, fontWeight: 600 }}>{idx.score.toFixed(1)}</div>
              </div>
            ))}
          </div>
        )}
        <div style={{ borderTop: "1px solid var(--rule)" }}>
          {snap.indicators.slice(0, 20).map((ind, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--rule)", fontSize: 13 }}>
              <span>{ind.displayName}</span>
              <span className="mono">{ind.value === null ? "—" : ind.value.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
            </div>
          ))}
        </div>
      </main>
    );
  }

  // compare/correlation snapshots render as raw JSON for now — full visual
  // parity with their live pages is a reasonable follow-up, but this at
  // least makes the share link functional end-to-end.
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: "40px 24px 96px" }}>
      <div style={{ background: "var(--paper-raised)", border: "1px solid var(--signal-flag)", borderRadius: 8, padding: 12, marginBottom: 24, fontSize: 13 }}>
        📸 Snapshot from <strong>{createdAt}</strong> — this is frozen, not live.
      </div>
      <pre className="mono" style={{ fontSize: 12, whiteSpace: "pre-wrap", background: "var(--paper-raised)", padding: 16, borderRadius: 8 }}>
        {JSON.stringify(row.snapshot_data, null, 2)}
      </pre>
    </main>
  );
}
