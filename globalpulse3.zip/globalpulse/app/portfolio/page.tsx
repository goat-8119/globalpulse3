"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type Holding = {
  id: number;
  displayName: string;
  canonicalKey: string;
  unit: string | null;
  quantity: number;
  avgCostBasis: number | null;
  currentPrice: number | null;
  pctChange1d: number | null;
};
type Portfolio = { id: number; name: string; totalValue: number; holdings: Holding[] };
type IndicatorOption = { id: number; displayName: string };
type CountryOption = { iso3: string; name: string; flagEmoji: string | null };

function fmtMoney(v: number): string {
  return v.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

export default function PortfolioPage() {
  const [portfolios, setPortfolios] = useState<Portfolio[] | null>(null);
  const [newName, setNewName] = useState("");
  const [countries, setCountries] = useState<CountryOption[]>([]);
  const [activeIso3, setActiveIso3] = useState("USA");
  const [indicators, setIndicators] = useState<IndicatorOption[]>([]);
  const [addingTo, setAddingTo] = useState<number | null>(null);
  const [selectedIndicator, setSelectedIndicator] = useState<number | null>(null);
  const [quantity, setQuantity] = useState("");
  const [costBasis, setCostBasis] = useState("");

  function refresh() {
    fetch("/api/portfolio").then((r) => r.json()).then((d) => setPortfolios(d.portfolios ?? []));
  }

  useEffect(() => {
    refresh();
    fetch("/api/countries").then((r) => r.json()).then((d) => setCountries(d.countries ?? []));
  }, []);

  useEffect(() => {
    fetch(`/api/countries/${activeIso3}`)
      .then((r) => r.json())
      .then((d) => setIndicators((d.indicators ?? []).map((i: { id: number; displayName: string }) => ({ id: i.id, displayName: i.displayName }))));
  }, [activeIso3]);

  async function createPortfolio() {
    if (!newName.trim()) return;
    await fetch("/api/portfolio", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: newName.trim() }) });
    setNewName("");
    refresh();
  }

  async function addHolding(portfolioId: number) {
    if (!selectedIndicator || !quantity) return;
    await fetch(`/api/portfolio/${portfolioId}/holdings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ indicatorId: selectedIndicator, quantity: Number(quantity), avgCostBasis: costBasis ? Number(costBasis) : null }),
    });
    setAddingTo(null);
    setQuantity("");
    setCostBasis("");
    setSelectedIndicator(null);
    refresh();
  }

  async function removeHolding(portfolioId: number, holdingId: number) {
    await fetch(`/api/portfolio/${portfolioId}/holdings?holdingId=${holdingId}`, { method: "DELETE" });
    refresh();
  }

  return (
    <main style={{ maxWidth: 800, margin: "0 auto", padding: "40px 24px 96px" }}>
      <Link href="/" className="mono" style={{ fontSize: 12, color: "var(--ink-muted)", textDecoration: "none" }}>
        ← ALL COUNTRIES
      </Link>
      <h1 style={{ fontSize: 26, margin: "16px 0 8px" }}>Portfolio</h1>
      <p style={{ color: "var(--ink-muted)", marginTop: 0, marginBottom: 28, maxWidth: 560 }}>
        Manual entry only — no broker connection. Values update against the same live data as the rest of the site.
      </p>

      <div style={{ display: "flex", gap: 10, marginBottom: 32 }}>
        <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="New portfolio name" style={{ flex: 1 }} />
        <button
          onClick={createPortfolio}
          style={{ background: "var(--accent-gold)", color: "var(--paper)", border: "none", borderRadius: 6, padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}
        >
          Create
        </button>
      </div>

      {portfolios === null && <p className="mono" style={{ color: "var(--ink-muted)", fontSize: 13 }}>loading…</p>}
      {portfolios !== null && portfolios.length === 0 && <p style={{ color: "var(--ink-muted)" }}>No portfolios yet — create one above.</p>}

      {(portfolios ?? []).map((p) => (
        <section key={p.id} style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 8, padding: 20, marginBottom: 20 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 16 }}>
            <h2 style={{ fontSize: 17 }}>{p.name}</h2>
            <span className="mono" style={{ fontSize: 18, fontWeight: 600 }}>${fmtMoney(p.totalValue)}</span>
          </div>

          {p.holdings.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              {p.holdings.map((h) => {
                const value = h.currentPrice === null ? null : h.currentPrice * h.quantity;
                const gainPct = h.avgCostBasis && h.currentPrice ? ((h.currentPrice - h.avgCostBasis) / h.avgCostBasis) * 100 : null;
                return (
                  <div key={h.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid var(--rule)", fontSize: 13 }}>
                    <span>
                      {h.displayName} <span className="mono muted" style={{ fontSize: 11, color: "var(--ink-muted)" }}>× {h.quantity}</span>
                    </span>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <span className="mono">{value === null ? "—" : `$${fmtMoney(value)}`}</span>
                      {gainPct !== null && (
                        <span className={`mono ${gainPct >= 0 ? "up" : "down"}`} style={{ fontSize: 11 }}>
                          {gainPct > 0 ? "+" : ""}
                          {gainPct.toFixed(1)}%
                        </span>
                      )}
                      <button onClick={() => removeHolding(p.id, h.id)} className="mono" style={{ fontSize: 11, color: "var(--signal-down)" }}>
                        remove
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {addingTo === p.id ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <select value={activeIso3} onChange={(e) => setActiveIso3(e.target.value)}>
                {countries.map((c) => (
                  <option key={c.iso3} value={c.iso3}>
                    {c.flagEmoji} {c.name}
                  </option>
                ))}
              </select>
              <select value={selectedIndicator ?? ""} onChange={(e) => setSelectedIndicator(Number(e.target.value))}>
                <option value="">Select an indicator…</option>
                {indicators.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.displayName}
                  </option>
                ))}
              </select>
              <div style={{ display: "flex", gap: 8 }}>
                <input value={quantity} onChange={(e) => setQuantity(e.target.value)} placeholder="Quantity" type="number" style={{ flex: 1 }} />
                <input value={costBasis} onChange={(e) => setCostBasis(e.target.value)} placeholder="Avg cost (optional)" type="number" style={{ flex: 1 }} />
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  onClick={() => addHolding(p.id)}
                  style={{ background: "var(--accent-gold)", color: "var(--paper)", border: "none", borderRadius: 6, padding: "6px 14px", fontSize: 12, fontWeight: 600 }}
                >
                  Add
                </button>
                <button onClick={() => setAddingTo(null)} className="mono" style={{ fontSize: 12, color: "var(--ink-muted)" }}>
                  cancel
                </button>
              </div>
            </div>
          ) : (
            <button onClick={() => setAddingTo(p.id)} className="mono" style={{ fontSize: 12, color: "var(--accent-gold)" }}>
              + add holding
            </button>
          )}
        </section>
      ))}
    </main>
  );
}
