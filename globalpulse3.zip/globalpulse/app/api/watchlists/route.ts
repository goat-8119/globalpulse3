import { NextResponse } from "next/server";
import { z } from "zod";
import { getSql } from "@/lib/db";

export const dynamic = "force-dynamic";

const CreateWatchlistSchema = z.object({
  name: z.string().min(1).max(200),
  indicatorIds: z.array(z.number().int().positive()).max(100),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = CreateWatchlistSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid body", issues: parsed.error.issues }, { status: 400 });
  }

  const sql = getSql();
  const rows = await sql`
    INSERT INTO watchlists (name, indicator_ids)
    VALUES (${parsed.data.name}, ${parsed.data.indicatorIds})
    RETURNING id, name, indicator_ids
  `;

  return NextResponse.json({ watchlist: rows[0] }, { status: 201 });
}

export async function GET() {
  const sql = getSql();
  const watchlists = await sql`SELECT id, name, indicator_ids FROM watchlists ORDER BY id DESC`;

  // One query for every indicator referenced across every watchlist, then
  // grouped client-side — avoids an N+1 across watchlists.
  const allIds = [...new Set(watchlists.flatMap((w) => (w.indicator_ids as number[]) ?? []))];
  const indicatorRows =
    allIds.length === 0
      ? []
      : await sql`
          SELECT i.id, i.display_name, i.unit, c.iso3, c.flag_emoji, c.name AS country_name,
                 lo.value, lo.pct_change_1d
          FROM indicators i
          JOIN countries c ON c.id = i.country_id
          LEFT JOIN latest_observation lo ON lo.indicator_id = i.id
          WHERE i.id = ANY(${allIds})
        `;
  const byId = new Map(indicatorRows.map((r) => [r.id as number, r]));

  const result = watchlists.map((w) => ({
    id: w.id,
    name: w.name,
    items: ((w.indicator_ids as number[]) ?? [])
      .map((id) => byId.get(id))
      .filter((r): r is NonNullable<typeof r> => r !== undefined)
      .map((r) => ({
        indicatorId: r.id,
        displayName: r.display_name,
        unit: r.unit,
        countryIso3: r.iso3,
        countryFlag: r.flag_emoji,
        countryName: r.country_name,
        value: r.value === null ? null : Number(r.value),
        pctChange1d: r.pct_change_1d === null ? null : Number(r.pct_change_1d),
      })),
  }));

  return NextResponse.json({ watchlists: result });
}
