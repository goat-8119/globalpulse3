"use client";

import { useState } from "react";
import { Sparkline } from "./sparkline";
import { IndicatorChart } from "./indicator-chart";

type Indicator = {
  id: number;
  category: string;
  canonicalKey: string;
  displayName: string;
  unit: string | null;
  value: number | null;
  pctChange1d: number | null;
  pctChange1y: number | null;
  isOutlier: boolean;
  sparkline: number[];
};

function fmtPct(v: number | null): string {
  if (v === null) return "—";
  const sign = v > 0 ? "+" : "";
  return `${sign}${v.toFixed(2)}%`;
}
function pctClass(v: number | null): string {
  if (v === null) return "";
  return v > 0 ? "up" : v < 0 ? "down" : "";
}

export function IndicatorTable({ iso3, grouped }: { iso3: string; grouped: Record<string, Indicator[]> }) {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  return (
    <>
      {Object.entries(grouped).map(([category, rows]) => (
        <section key={category} style={{ marginBottom: 32 }}>
          <h2 style={{ fontSize: 14, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--ink-muted)", marginBottom: 12 }}>
            {category}
          </h2>
          <div style={{ borderTop: "1px solid var(--rule)" }}>
            {rows.map((ind) => (
              <div key={ind.id}>
                <button
                  onClick={() => setExpandedId(expandedId === ind.id ? null : ind.id)}
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr auto auto auto auto",
                    gap: 16,
                    alignItems: "center",
                    padding: "10px 0",
                    borderBottom: "1px solid var(--rule)",
                    width: "100%",
                    background: "none",
                    border: "none",
                    borderBottomWidth: 1,
                    borderBottomStyle: "solid",
                    borderBottomColor: "var(--rule)",
                    cursor: "pointer",
                    font: "inherit",
                    color: "inherit",
                    textAlign: "left",
                  }}
                >
                  <span>
                    {ind.displayName}
                    {ind.isOutlier && (
                      <span className="amber mono" style={{ fontSize: 10, marginLeft: 8 }}>
                        ● ANOMALY
                      </span>
                    )}
                  </span>
                  <Sparkline values={ind.sparkline} />
                  <span className="mono" style={{ textAlign: "right", minWidth: 90 }}>
                    {ind.value === null ? "—" : ind.value.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    {ind.unit && ind.unit !== "%" ? ` ${ind.unit}` : ""}
                  </span>
                  <span className={`mono ${pctClass(ind.pctChange1d)}`} style={{ textAlign: "right", minWidth: 70 }}>
                    {fmtPct(ind.pctChange1d)}
                  </span>
                  <span className={`mono ${pctClass(ind.pctChange1y)}`} style={{ textAlign: "right", minWidth: 70 }}>
                    {fmtPct(ind.pctChange1y)}
                  </span>
                </button>
                {expandedId === ind.id && <IndicatorChart iso3={iso3} canonicalKey={ind.canonicalKey} unit={ind.unit} />}
              </div>
            ))}
          </div>
        </section>
      ))}
    </>
  );
}
