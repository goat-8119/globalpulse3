import { NextResponse } from "next/server";
import { z } from "zod";
import { getSql } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const sql = getSql();
  const portfolios = await sql`SELECT id, name, created_at FROM portfolios ORDER BY created_at DESC`;

  // N+1 avoided: one query for all holdings across all portfolios, grouped client-side.
  const holdings = await sql`
    SELECT ph.portfolio_id, ph.id, ph.quantity, ph.avg_cost_basis,
           i.display_name, i.unit, i.canonical_key,
           lo.value AS current_price, lo.pct_change_1d
    FROM portfolio_holdings ph
    JOIN indicators i ON i.id = ph.indicator_id
    LEFT JOIN latest_observation lo ON lo.indicator_id = i.id
  `;

  const result = portfolios.map((p) => {
    const rows = holdings.filter((h) => h.portfolio_id === p.id);
    const totalValue = rows.reduce((sum, h) => sum + (h.current_price === null ? 0 : Number(h.current_price) * Number(h.quantity)), 0);
    return {
      id: p.id,
      name: p.name,
      createdAt: p.created_at,
      totalValue,
      holdings: rows.map((h) => ({
        id: h.id,
        displayName: h.display_name,
        canonicalKey: h.canonical_key,
        unit: h.unit,
        quantity: Number(h.quantity),
        avgCostBasis: h.avg_cost_basis === null ? null : Number(h.avg_cost_basis),
        currentPrice: h.current_price === null ? null : Number(h.current_price),
        pctChange1d: h.pct_change_1d === null ? null : Number(h.pct_change_1d),
      })),
    };
  });

  return NextResponse.json({ portfolios: result });
}

const CreatePortfolioSchema = z.object({ name: z.string().min(1).max(200) });

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = CreatePortfolioSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid body" }, { status: 400 });

  const sql = getSql();
  const rows = await sql`INSERT INTO portfolios (name) VALUES (${parsed.data.name}) RETURNING id, name, created_at`;
  return NextResponse.json({ portfolio: rows[0] }, { status: 201 });
}
