"use client";

import { useEffect, useState } from "react";

type Headline = { title: string; url: string; domain: string | null };

export function NewsPanel({ iso3 }: { iso3: string }) {
  const [headlines, setHeadlines] = useState<Headline[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/news?country=${iso3}`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setHeadlines((d.headlines ?? []).slice(0, 5));
      })
      .catch(() => {
        if (!cancelled) setHeadlines([]);
      });
    return () => {
      cancelled = true;
    };
  }, [iso3]);

  if (headlines !== null && headlines.length === 0) return null; // no country-specific coverage found — don't show an empty panel

  return (
    <section style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 8, padding: "16px 20px", marginBottom: 32 }}>
      <div style={{ fontSize: 10, color: "var(--ink-muted)", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.04em" }}>
        Recent Headlines
      </div>
      {headlines === null ? (
        <div className="mono" style={{ fontSize: 12, color: "var(--ink-muted)" }}>loading…</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {headlines.map((h, i) => (
            <a key={i} href={h.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 13, textDecoration: "none", color: "var(--ink)", lineHeight: 1.4 }}>
              {h.title}
              {h.domain && <span className="mono" style={{ color: "var(--ink-muted)", fontSize: 11 }}> — {h.domain}</span>}
            </a>
          ))}
        </div>
      )}
    </section>
  );
}
