import { describe, it, expect } from "vitest";
import { toGdeltCountryToken } from "./gdelt";

describe("toGdeltCountryToken", () => {
  it("lowercases a simple single-word country name", () => {
    expect(toGdeltCountryToken("France")).toBe("france");
  });

  it("strips spaces from a multi-word country name", () => {
    expect(toGdeltCountryToken("United Arab Emirates")).toBe("unitedarabemirates");
  });

  it("documents a known limitation: accented characters are dropped, not transliterated", () => {
    // The regex only keeps ASCII a-z, so 'ô' is stripped rather than
    // converted to 'o' — "Côte d'Ivoire" becomes "ctedivoire", not the
    // "coteivoire" GDELT likely actually expects. This is a real, disclosed
    // gap (see the comment above toGdeltCountryToken), not a silent bug —
    // this test exists so a future change to the transform logic doesn't
    // accidentally "fix" this in a way nobody notices either.
    expect(toGdeltCountryToken("Côte d'Ivoire")).toBe("ctedivoire");
  });

  it("handles a country name that is already a single lowercase-able word", () => {
    expect(toGdeltCountryToken("Japan")).toBe("japan");
  });
});
