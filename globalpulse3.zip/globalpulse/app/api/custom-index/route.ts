import { NextResponse } from "next/server";
import { z } from "zod";
import { getSql } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const sql = getSql();
  const indexes = await sql`SELECT id, name, weights, created_at FROM custom_indexes ORDER BY created_at DESC`;

  const results = [];
  for (const idx of indexes) {
    const weights = idx.weights as Record<string, number>;
    const indicatorIds = Object.keys(weights).map(Number);
    if (indicatorIds.length === 0) {
      results.push({ id: idx.id, name: idx.name, createdAt: idx.created_at, score: null, components: [] });
      continue;
    }

    const rows = await sql`
      SELECT i.id, i.display_name, lo.pct_change_1d
      FROM indicators i
      LEFT JOIN latest_observation lo ON lo.indicator_id = i.id
      WHERE i.id = ANY(${indicatorIds})
    `;

    // Score: weighted average of each component's 1-day % change, squashed
    // to a 0-100 scale the same way market_momentum does (50 = neutral) —
    // consistent with every other score on the site, so a custom index
    // reads the same way as the built-in ones.
    let weightedSum = 0;
    let weightTotal = 0;
    const components = rows.map((r) => {
      const w = weights[String(r.id)] ?? 0;
      const pct = r.pct_change_1d === null ? null : Number(r.pct_change_1d);
      if (pct !== null) {
        weightedSum += pct * w;
        weightTotal += Math.abs(w);
      }
      return { indicatorId: r.id, displayName: r.display_name, weight: w, pctChange1d: pct };
    });

    const score = weightTotal > 0 ? Math.max(0, Math.min(100, 50 + (weightedSum / weightTotal) * 5)) : null;
    results.push({ id: idx.id, name: idx.name, createdAt: idx.created_at, score, components });
  }

  return NextResponse.json({ indexes: results });
}

const CreateIndexSchema = z.object({
  name: z.string().min(1).max(200),
  weights: z.record(z.string(), z.number()).refine((w) => Object.keys(w).length > 0, "At least one component required"),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = CreateIndexSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid body", issues: parsed.error.issues }, { status: 400 });

  const sql = getSql();
  const rows = await sql`
    INSERT INTO custom_indexes (name, weights) VALUES (${parsed.data.name}, ${JSON.stringify(parsed.data.weights)})
    RETURNING id, name, weights, created_at
  `;
  return NextResponse.json({ index: rows[0] }, { status: 201 });
}
