// Backtest / track record engine. This is the honest answer to "make the
// model more accurate": instead of tuning the composite signal to produce
// better-looking numbers (which doesn't change its real predictive value —
// see quant-signals.ts header), this replays the signal against real
// historical data and reports what actually happened. The output is a hit
// rate, not a promise. A well-known industry fact this should NOT beat by
// much: 52-55% directional accuracy is what "good" looks like for real
// quant signals. If this backtest shows 70%+, that's a red flag for
// overfitting or a lookahead bug, not something to celebrate.

import { momentumSignal, meanReversionSignal, volAdjustedMomentumSignal, computeCompositeSignal } from "./quant-signals";

export type PricePoint = { t: number; close: number; pctChange1d: number | null };

export type BacktestTrade = {
  signalDate: number; // index into the series where the signal was read
  signalScore: number; // 0-100
  signalDirection: "bullish" | "bearish" | "neutral";
  actualForwardReturn: number; // % change from signal date to horizon date
  correct: boolean; // did the signal's direction match the actual forward move?
};

export type BacktestResult = {
  trades: BacktestTrade[];
  hitRate: number; // fraction of non-neutral-signal trades where direction was correct
  totalSignals: number;
  neutralSignals: number; // signals too close to 50 to call a direction — excluded from hitRate
  meanForwardReturnWhenBullish: number | null;
  meanForwardReturnWhenBearish: number | null;
};

const NEUTRAL_BAND = 5; // score within 50±5 is not counted as a directional call

/**
 * Replays the composite signal at every point in history where enough
 * trailing data exists, then checks what actually happened over the next
 * `horizonDays` trading days. This is a strict walk-forward test — at each
 * signal date, only data STRICTLY BEFORE that date is used to compute the
 * signal (see the slice in the caller), so there is no lookahead bias.
 */
export function runBacktest(series: PricePoint[], horizonDays: number = 5, minTrailingDays: number = 30): BacktestResult {
  const trades: BacktestTrade[] = [];

  for (let i = minTrailingDays; i < series.length - horizonDays; i++) {
    const trailing = series.slice(0, i + 1); // everything up to AND INCLUDING day i — the signal's own "today"
    const values = trailing.map((p) => p.close);
    const dailyChanges = trailing.map((p) => p.pctChange1d ?? 0);

    const latest = trailing[trailing.length - 1]!;
    const momentum = momentumSignal({ pctChange1d: latest.pctChange1d, pctChange1w: null, pctChange1m: null });
    const reversion = meanReversionSignal(values);
    const volAdj = volAdjustedMomentumSignal(dailyChanges);
    const composite = computeCompositeSignal(momentum, reversion, volAdj);
    if (!composite) continue;

    const horizonPoint = series[i + horizonDays];
    if (!horizonPoint) continue;
    const actualForwardReturn = ((horizonPoint.close - latest.close) / latest.close) * 100;

    const direction: BacktestTrade["signalDirection"] = composite.score > 50 + NEUTRAL_BAND ? "bullish" : composite.score < 50 - NEUTRAL_BAND ? "bearish" : "neutral";

    const correct =
      direction === "bullish" ? actualForwardReturn > 0 : direction === "bearish" ? actualForwardReturn < 0 : false; // neutral calls are never "correct" — they're excluded from hitRate below

    trades.push({ signalDate: i, signalScore: composite.score, signalDirection: direction, actualForwardReturn, correct });
  }

  const directional = trades.filter((t) => t.signalDirection !== "neutral");
  const hitRate = directional.length > 0 ? directional.filter((t) => t.correct).length / directional.length : 0;

  const bullishReturns = trades.filter((t) => t.signalDirection === "bullish").map((t) => t.actualForwardReturn);
  const bearishReturns = trades.filter((t) => t.signalDirection === "bearish").map((t) => t.actualForwardReturn);

  return {
    trades,
    hitRate,
    totalSignals: trades.length,
    neutralSignals: trades.length - directional.length,
    meanForwardReturnWhenBullish: bullishReturns.length > 0 ? bullishReturns.reduce((a, b) => a + b, 0) / bullishReturns.length : null,
    meanForwardReturnWhenBearish: bearishReturns.length > 0 ? bearishReturns.reduce((a, b) => a + b, 0) / bearishReturns.length : null,
  };
}
