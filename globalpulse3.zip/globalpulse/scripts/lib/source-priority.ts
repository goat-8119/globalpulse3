// Section 5: "before writing, the ingestion script checks whether
// (country_id, canonical_key) is already owned by a higher-priority source."
//
// BLS ranks above World Bank/IMF/FRED for US series specifically: BLS is the
// primary US government agency that PRODUCES this data — FRED's and World
// Bank's US labor/price numbers are themselves sourced from BLS releases,
// just aggregated and sometimes annualized. Preferring the primary source
// over downstream aggregators is the correct priority rule, not just
// "newest source wins." BLS only ever seeds US rows (it has no data for
// other countries), so in practice this only matters for iso3 = 'USA'.
export type MacroSource = "bls" | "worldbank" | "imf" | "fred";

const SOURCE_PRIORITY: Record<MacroSource, number> = { bls: 0, worldbank: 1, imf: 2, fred: 3 };

/** True if `incoming` is allowed to write/own a slot currently held by `existing`. */
export function sourceCanOverride(existing: MacroSource, incoming: MacroSource): boolean {
  return SOURCE_PRIORITY[incoming] <= SOURCE_PRIORITY[existing];
}
