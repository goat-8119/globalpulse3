import { NextResponse } from "next/server";
import { getSql } from "@/lib/db";
import { fetchFinanceHeadlines } from "@/scripts/lib/gdelt";

// Deliberately NOT force-dynamic. Every other route in this app reads only
// from Postgres, refreshed by a cron job, so force-dynamic is correct there
// (Section 2: never call a third party on a user's request). This route is
// the one real exception — it IS the live call, since news doesn't fit the
// "backfill and store" shape the rest of the schema uses (Section 5 already
// scoped News out of the indicators/observations schema for this reason).
// A short revalidate window keeps this from hammering GDELT's free service
// on every page load, without pretending this is DB-backed when it isn't.
export const revalidate = 300; // 5 minutes

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const iso3 = searchParams.get("country");

  let countryName: string | undefined;
  if (iso3) {
    const sql = getSql();
    const rows = await sql`SELECT name FROM countries WHERE iso3 = ${iso3.toUpperCase()}`;
    if (rows.length === 0) {
      return NextResponse.json({ error: `Country '${iso3}' not found` }, { status: 404 });
    }
    countryName = rows[0]!.name as string;
  }

  try {
    const headlines = await fetchFinanceHeadlines({ countryName, maxRecords: 20 });
    return NextResponse.json({ headlines, countryFilter: countryName ?? null });
  } catch (err) {
    // GDELT is a free, rate-limited service — a transient failure here
    // shouldn't be a 500 that looks like our bug. Degrade to an empty list
    // with a clear signal, rather than crash the page that embeds this.
    return NextResponse.json({ headlines: [], countryFilter: countryName ?? null, error: (err as Error).message }, { status: 200 });
  }
}
