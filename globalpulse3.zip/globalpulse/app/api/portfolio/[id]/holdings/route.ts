import { NextResponse } from "next/server";
import { z } from "zod";
import { getSql } from "@/lib/db";

export const dynamic = "force-dynamic";

const AddHoldingSchema = z.object({
  indicatorId: z.number().int().positive(),
  quantity: z.number().positive(),
  avgCostBasis: z.number().positive().nullable().optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const portfolioId = Number(id);
  if (!Number.isInteger(portfolioId)) return NextResponse.json({ error: "Invalid portfolio id" }, { status: 400 });

  const body = await req.json().catch(() => null);
  const parsed = AddHoldingSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid body", issues: parsed.error.issues }, { status: 400 });

  const sql = getSql();

  const portfolioRows = await sql`SELECT id FROM portfolios WHERE id = ${portfolioId}`;
  if (portfolioRows.length === 0) return NextResponse.json({ error: "Portfolio not found" }, { status: 404 });

  const rows = await sql`
    INSERT INTO portfolio_holdings (portfolio_id, indicator_id, quantity, avg_cost_basis)
    VALUES (${portfolioId}, ${parsed.data.indicatorId}, ${parsed.data.quantity}, ${parsed.data.avgCostBasis ?? null})
    RETURNING id, quantity, avg_cost_basis
  `;
  return NextResponse.json({ holding: rows[0] }, { status: 201 });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const portfolioId = Number(id);
  const { searchParams } = new URL(req.url);
  const holdingId = Number(searchParams.get("holdingId"));
  if (!Number.isInteger(portfolioId) || !Number.isInteger(holdingId)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const sql = getSql();
  await sql`DELETE FROM portfolio_holdings WHERE id = ${holdingId} AND portfolio_id = ${portfolioId}`;
  return NextResponse.json({ ok: true });
}
