import { describe, it, expect } from "vitest";
import { parseBlsDataPoints } from "./bls";

function point(year: string, period: string, value: string) {
  return { year, period, periodName: "x", value };
}

describe("parseBlsDataPoints", () => {
  it("keeps regular monthly periods M01-M12", () => {
    const result = parseBlsDataPoints([point("2024", "M01", "4.1"), point("2024", "M12", "4.3")]);
    expect(result).toHaveLength(2);
    expect(result[0]!.month).toBe(1);
    expect(result[1]!.month).toBe(12);
  });

  it("excludes M13 (annual average) — this is the critical case", () => {
    // BLS includes an M13 "annual average" row alongside the 12 real months.
    // Including it would silently insert a 13th, non-chronological point
    // into what should be a clean monthly series, corrupting every
    // computeChanges() call downstream.
    const result = parseBlsDataPoints([point("2024", "M01", "4.1"), point("2024", "M13", "4.2"), point("2024", "M12", "4.3")]);
    expect(result).toHaveLength(2);
    expect(result.some((r) => r.month === 13)).toBe(false);
  });

  it("parses value strings to numbers", () => {
    const result = parseBlsDataPoints([point("2024", "M06", "3.75")]);
    expect(result[0]!.value).toBeCloseTo(3.75);
  });

  it("drops points with a non-numeric value", () => {
    const result = parseBlsDataPoints([point("2024", "M01", "not-a-number"), point("2024", "M02", "4.0")]);
    expect(result).toHaveLength(1);
    expect(result[0]!.month).toBe(2);
  });

  it("returns an empty array for an empty input", () => {
    expect(parseBlsDataPoints([])).toEqual([]);
  });
});
