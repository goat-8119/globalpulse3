"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";

type CountryOption = { iso3: string; name: string; flagEmoji: string | null };

const STATIC_PAGES = [
  { label: "Countries (home)", href: "/" },
  { label: "Compare", href: "/compare" },
  { label: "Correlation Matrix", href: "/correlation" },
  { label: "Watchlists", href: "/watchlist" },
  { label: "Anomaly Feed", href: "/anomalies" },
  { label: "Portfolio", href: "/portfolio" },
  { label: "Custom Index Builder", href: "/custom-index" },
  { label: "Track Record", href: "/backtest" },
  { label: "Headlines", href: "/news" },
  { label: "API Docs", href: "/api-docs" },
];

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [countries, setCountries] = useState<CountryOption[]>([]);
  const router = useRouter();

  useEffect(() => {
    if (open && countries.length === 0) {
      fetch("/api/countries").then((r) => r.json()).then((d) => setCountries(d.countries ?? []));
    }
  }, [open, countries.length]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "k") {
      e.preventDefault();
      setOpen((prev) => !prev);
    }
    if (e.key === "Escape") setOpen(false);
  }, []);

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  if (!open) return null;

  const q = query.toLowerCase().trim();
  const matchedPages = STATIC_PAGES.filter((p) => p.label.toLowerCase().includes(q));
  const matchedCountries = countries.filter((c) => c.name.toLowerCase().includes(q) || c.iso3.toLowerCase().includes(q)).slice(0, 8);

  function go(href: string) {
    setOpen(false);
    setQuery("");
    router.push(href);
  }

  return (
    <div
      onClick={() => setOpen(false)}
      style={{ position: "fixed", inset: 0, background: "rgba(36,31,25,0.35)", zIndex: 1000, display: "flex", alignItems: "flex-start", justifyContent: "center", paddingTop: "12vh" }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ background: "var(--paper-raised)", border: "1px solid var(--rule)", borderRadius: 10, width: 480, maxWidth: "90vw", maxHeight: "60vh", overflow: "hidden", boxShadow: "0 20px 50px rgba(36,31,25,0.18)" }}
      >
        <input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Jump to a page or country…"
          style={{ width: "100%", padding: "16px", fontSize: 15, background: "transparent", border: "none", borderBottom: "1px solid var(--rule)", color: "var(--ink)", outline: "none" }}
        />
        <div style={{ overflowY: "auto", maxHeight: "calc(60vh - 60px)", padding: "8px 0" }}>
          {matchedPages.length > 0 && (
            <div style={{ padding: "4px 16px" }}>
              <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", textTransform: "uppercase", padding: "6px 0" }}>Pages</div>
              {matchedPages.map((p) => (
                <button key={p.href} onClick={() => go(p.href)} style={{ display: "block", width: "100%", textAlign: "left", padding: "8px 4px", fontSize: 14, borderRadius: 6, cursor: "pointer" }}>
                  {p.label}
                </button>
              ))}
            </div>
          )}
          {matchedCountries.length > 0 && (
            <div style={{ padding: "4px 16px" }}>
              <div className="mono" style={{ fontSize: 10, color: "var(--ink-muted)", textTransform: "uppercase", padding: "6px 0" }}>Countries</div>
              {matchedCountries.map((c) => (
                <button key={c.iso3} onClick={() => go(`/country/${c.iso3}`)} style={{ display: "block", width: "100%", textAlign: "left", padding: "8px 4px", fontSize: 14, borderRadius: 6, cursor: "pointer" }}>
                  {c.flagEmoji} {c.name}
                </button>
              ))}
            </div>
          )}
          {matchedPages.length === 0 && matchedCountries.length === 0 && (
            <div style={{ padding: "16px", fontSize: 13, color: "var(--ink-muted)" }}>No matches.</div>
          )}
        </div>
      </div>
    </div>
  );
}
