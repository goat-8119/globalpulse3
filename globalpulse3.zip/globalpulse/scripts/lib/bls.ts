import { z } from "zod";
import { fetchWithRetry } from "./retry";

// BLS API v2: POST (not GET) with a JSON body — confirmed against bls.gov's
// own API signature docs and multiple independent third-party wrappers.
// Without a registration key: up to 25 series/request, ~500 queries/day per
// IP. With a free key: up to 50 series/request and a higher daily limit.
// This client works either way — apiKey is optional.
const BLS_ENDPOINT = "https://api.bls.gov/publicAPI/v2/timeseries/data/";

const BlsDataPointSchema = z.object({
  year: z.string(),
  period: z.string(), // "M01".."M12" = calendar months, "M13" = annual average (excluded below)
  periodName: z.string(),
  value: z.string(), // BLS returns numbers as strings
});

const BlsSeriesSchema = z.object({
  seriesID: z.string(),
  data: z.array(BlsDataPointSchema),
});

const BlsResponseSchema = z.object({
  status: z.string(),
  message: z.array(z.string()).optional(),
  Results: z
    .object({
      series: z.array(BlsSeriesSchema),
    })
    .optional(),
});

export type BlsObservation = { year: string; month: number; value: number };
export type BlsSeriesResult = { seriesId: string; observations: BlsObservation[] };

/**
 * Pure transform: BLS's raw data points -> clean monthly observations.
 * Extracted from the network call so the "exclude M13 (annual average)"
 * logic — the part most likely to silently regress — is independently
 * unit tested (bls.test.ts) rather than only exercised via a live API call.
 */
export function parseBlsDataPoints(dataPoints: z.infer<typeof BlsDataPointSchema>[]): BlsObservation[] {
  return dataPoints
    .filter((d) => /^M(0[1-9]|1[0-2])$/.test(d.period)) // exclude M13 (annual average) — monthly granularity only
    .map((d) => ({ year: d.year, month: Number(d.period.slice(1)), value: Number(d.value) }))
    .filter((d) => !Number.isNaN(d.value));
}

const MAX_SERIES_PER_REQUEST_NO_KEY = 25;
const MAX_SERIES_PER_REQUEST_WITH_KEY = 50;

/**
 * Fetches one or more BLS series in a single batch call (BLS's API supports
 * multi-series requests natively — much more efficient than one call per
 * series). Automatically chunks if more series are requested than the
 * per-call limit allows.
 */
export async function fetchBlsSeries(seriesIds: string[], apiKey?: string): Promise<BlsSeriesResult[]> {
  const maxPerRequest = apiKey ? MAX_SERIES_PER_REQUEST_WITH_KEY : MAX_SERIES_PER_REQUEST_NO_KEY;
  const results: BlsSeriesResult[] = [];

  for (let i = 0; i < seriesIds.length; i += maxPerRequest) {
    const chunk = seriesIds.slice(i, i + maxPerRequest);
    const currentYear = new Date().getFullYear();

    const body: Record<string, unknown> = {
      seriesid: chunk,
      startyear: String(currentYear - 10), // 10y window per call; safe under both keyed/unkeyed limits
      endyear: String(currentYear),
    };
    if (apiKey) body.registrationkey = apiKey;

    const raw = await fetchWithRetry(BLS_ENDPOINT, {
      init: { method: "POST", body: JSON.stringify(body), headers: { "Content-Type": "application/json" } },
    });
    const parsed = BlsResponseSchema.safeParse(raw);

    if (!parsed.success) {
      throw new Error(`Unexpected BLS response shape: ${parsed.error.message}`);
    }
    if (parsed.data.status !== "REQUEST_SUCCEEDED") {
      throw new Error(`BLS API returned status '${parsed.data.status}': ${(parsed.data.message ?? []).join("; ")}`);
    }

    for (const series of parsed.data.Results?.series ?? []) {
      results.push({ seriesId: series.seriesID, observations: parseBlsDataPoints(series.data) });
    }
  }

  return results;
}
